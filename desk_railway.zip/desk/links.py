"""
THE ONLY place FOMO URLs are built.
Every Buy/Sell button, push, Activity row, Coin screen, etc. must go through these helpers.
Never drop r=savipww. Never shorten or wrap links.
"""

CHAIN_ID = {
    "solana": 1399811149,
    "robinhood": 4663,
    "base": 8453,
    "bnb": 56,
}

SIGNUP_URL = "https://fomo.family/r/savipww"


def coin_url(address: str, chain: str = "solana") -> str:
    if chain not in CHAIN_ID:
        # unknown chain → fallback to signup
        return SIGNUP_URL
    return (
        f"https://fomo.family/coin?address={address}"
        f"&chainId={CHAIN_ID[chain]}&r=savipww&source=share_link"
    )


def profile_url(handle: str) -> str:
    h = handle.lstrip("@")
    return f"https://fomo.family/profile/{h}?source=share_link&r=savipww"
